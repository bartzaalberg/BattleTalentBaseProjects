using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace CrossLink
{
    public class SoundEffectPlayer : MonoBehaviour
    {
        public SoundEffectInfo soundInfo;
        public bool loop = false;

        private void Start()
        {
            
        }
    }

}