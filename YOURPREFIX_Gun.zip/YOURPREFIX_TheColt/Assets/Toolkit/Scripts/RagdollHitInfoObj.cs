using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace CrossLink
{

    public class RagdollHitInfoObj : MonoBehaviour
    {
        public RagdollHitInfo hitInfo;
    }

}