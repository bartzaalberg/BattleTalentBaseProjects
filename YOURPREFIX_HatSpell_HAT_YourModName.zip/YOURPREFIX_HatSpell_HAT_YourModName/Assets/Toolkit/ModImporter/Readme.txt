1.place ModImporter in your sence.

2.place the mod you wana import in path "C:\Users[username]\AppData\LocalLow\CrossLink\BattleTalent\Mods".

3.click Unity "Play".

4.Click the "Spawn" list's button to spawn GameObject. click the "Script" list's button to check LuaScript.