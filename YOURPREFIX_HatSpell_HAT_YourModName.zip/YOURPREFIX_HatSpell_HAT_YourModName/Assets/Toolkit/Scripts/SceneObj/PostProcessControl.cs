﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
//using UnityEngine.Rendering.PostProcessing;
using UnityEngine.Rendering;
using UnityEngine.Rendering.Universal;

namespace CrossLink
{
    public class PostProcessControl : MonoBehaviour
    {
        public Volume vol;
    }
}