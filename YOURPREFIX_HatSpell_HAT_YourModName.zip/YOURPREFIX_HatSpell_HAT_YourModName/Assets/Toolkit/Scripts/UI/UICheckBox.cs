﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace CrossLink
{
    public class UICheckBox : MonoBehaviour
    {
        public UIButton btn;
        public Image trueImg;
        public Image falseImg;
        public Text tx;

    }
}
