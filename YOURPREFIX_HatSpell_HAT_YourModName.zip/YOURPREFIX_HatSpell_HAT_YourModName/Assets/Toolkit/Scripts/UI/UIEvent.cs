﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CrossLink
{

    public class UIEvent : MonoBehaviour
    {



        public bool isDisable = false;

        
    }

}