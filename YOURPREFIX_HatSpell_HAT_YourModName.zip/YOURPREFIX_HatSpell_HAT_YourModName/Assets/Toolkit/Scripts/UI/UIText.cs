﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace CrossLink
{

    public class UIText : MonoBehaviour
    {
        public Text tx;
        public string textId;
        public string[] randomTextId;


        public Text[] multiTx;
        public string[] multiId;


    }

}