﻿using UnityEngine;

public class CollisionEffectCustom : MonoBehaviour
{
    public AudioSource audioSource;

    void OnCollisionEnter(Collision collision)
    {
        print(collision.collider.name);
        if (collision.relativeVelocity.magnitude > 2)
        {
            audioSource.Play();
        }
    }
}
