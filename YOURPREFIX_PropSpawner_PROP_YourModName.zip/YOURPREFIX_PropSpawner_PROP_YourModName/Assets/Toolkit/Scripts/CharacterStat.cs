using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace CrossLink
{
	[Serializable]
	public class CharacterStat
	{
        [UnityEngine.SerializeField]
		public float BaseValue;
	}
}
