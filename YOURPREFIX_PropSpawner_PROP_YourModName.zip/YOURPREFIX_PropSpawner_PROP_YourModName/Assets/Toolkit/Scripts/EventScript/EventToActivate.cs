﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CrossLink
{

    public class EventToActivate : EventToBase
    {
        public GameObject obj;
        public GameObject[] otherObjs;
        public bool act = true;
    }
}