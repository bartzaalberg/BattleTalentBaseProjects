﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace CrossLink
{

    public class EventToSlowMo : EventToBase
    {

        public float slowMo = -1;
    }

}