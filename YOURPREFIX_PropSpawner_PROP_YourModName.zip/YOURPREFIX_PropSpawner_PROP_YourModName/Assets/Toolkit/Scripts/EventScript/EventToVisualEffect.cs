﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace CrossLink
{

    public class EventToVisualEffect : EventToBase
    {
        public string effectName;

        public Transform spawnTrans;

        public bool setScale = false;
    }

}