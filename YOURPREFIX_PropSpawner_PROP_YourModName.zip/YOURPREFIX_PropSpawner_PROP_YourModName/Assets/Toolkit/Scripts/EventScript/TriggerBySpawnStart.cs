﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CrossLink
{

    public class TriggerBySpawnStart : TriggerByBase
    {
        public SpawnPointMgr spawnPoint;
    }

}