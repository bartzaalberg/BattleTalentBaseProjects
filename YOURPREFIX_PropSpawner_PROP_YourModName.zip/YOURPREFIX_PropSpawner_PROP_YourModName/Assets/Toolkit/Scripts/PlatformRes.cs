using System.Collections;
using System.Collections.Generic;
using UnityEngine;

namespace CrossLink
{
    public class PlatformRes : MonoBehaviour
    {
        public GameObject[] pcOnlys;
        public GameObject[] questOnlys;
    }
}
