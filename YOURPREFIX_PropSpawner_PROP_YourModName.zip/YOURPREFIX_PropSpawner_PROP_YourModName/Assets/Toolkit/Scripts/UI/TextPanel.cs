﻿#if false//UNITY_EDITOR
#define DIA_LOG
#endif


using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace CrossLink
{

    [System.Serializable]
    public class DialogueData
    {
        public string[] lines;
    }
}