ZeroBrane IDE auto-complete
•copy syntax.lua to ZeroBraneStudio/api/lua.
•open ZeroBrane Studio and click Edit->Preferances->Settings User to open user.lua.
•write "table.insert(api, 'syntax')" in user.lua.
