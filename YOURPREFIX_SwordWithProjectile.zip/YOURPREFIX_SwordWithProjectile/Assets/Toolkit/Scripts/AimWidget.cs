using System.Collections;
using System.Collections.Generic;
using UnityEngine;


namespace CrossLink
{

    public class AimWidget : MonoBehaviour
    {
        public LayerMask aimMask;
        public LayerMask hitMask;
        public Transform aimPoint;
    }

}
